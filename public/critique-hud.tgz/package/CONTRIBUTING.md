# Contributions

Unsolicited contributions are temporarily paused while copyright ownership,
commercialisation rights, and the project's institutional licensing framework
are reviewed.

Do not submit source code, documentation, designs, datasets, recordings,
prompts, or other creative material unless the repository maintainer has first
confirmed in writing that an approved contribution agreement is in place.

See `LICENSE.md` for the project's current licensing status.
